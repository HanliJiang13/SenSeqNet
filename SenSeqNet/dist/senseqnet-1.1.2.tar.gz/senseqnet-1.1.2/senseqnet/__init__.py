# senseqnet/__init__.py

__version__ = "1.1.2"
